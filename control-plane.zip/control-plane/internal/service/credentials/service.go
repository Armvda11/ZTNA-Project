package credentials

import (
	"context"
	"fmt"
	"strings"
	"time"

	"control-plane/internal/config"
	"control-plane/internal/crypto/sshca"
	domainErrors "control-plane/internal/domain/errors"
	"control-plane/internal/domain/model"
	"control-plane/internal/store/sqlite"

	"golang.org/x/crypto/ssh"
)

type Service struct {
	ca  *sshca.CA
	cfg config.SSHCAConfig
	db  *sqlite.Store
}

func New(ca *sshca.CA, cfg config.SSHCAConfig, db *sqlite.Store) *Service {
	return &Service{ca: ca, cfg: cfg, db: db}
}

type IssueRequest struct {
	Subject   model.Subject
	PublicKey string
	TTL       *time.Duration
}

type IssueResponse struct {
	Certificate string
	ValidBefore time.Time
	Principal   string
}

func (s *Service) IssueSSHCert(ctx context.Context, req IssueRequest) (IssueResponse, error) {
	if err := s.db.UpsertUser(ctx, req.Subject); err != nil {
		return IssueResponse{}, err
	}

	parsedKey, _, _, _, err := ssh.ParseAuthorizedKey([]byte(req.PublicKey))
	if err != nil {
		return IssueResponse{}, fmt.Errorf("parse public key: %w", err)
	}

	ttl, err := time.ParseDuration(s.cfg.DefaultTTL)
	if err != nil {
		return IssueResponse{}, fmt.Errorf("invalid sshca default ttl: %w", err)
	}
	if req.TTL != nil {
		ttl = *req.TTL
	}

	minTTL := parseDurationOrZero(s.cfg.MinTTL)
	maxTTL := parseDurationOrZero(s.cfg.MaxTTL)
	if minTTL > 0 && ttl < minTTL {
		return IssueResponse{}, domainErrors.ErrInvalidInput
	}
	if maxTTL > 0 && ttl > maxTTL {
		return IssueResponse{}, domainErrors.ErrInvalidInput
	}

	principals := resolvePrincipals(s.cfg.AllowedPrincipals, req.Subject)
	if len(principals) == 0 {
		return IssueResponse{}, domainErrors.ErrInvalidInput
	}

	cert, validBefore, err := s.ca.SignUserCert(parsedKey, principals, ttl)
	if err != nil {
		return IssueResponse{}, err
	}

	return IssueResponse{
		Certificate: cert,
		ValidBefore: validBefore,
		Principal:   principals[0],
	}, nil
}

func resolvePrincipals(allowed []string, subject model.Subject) []string {
	if len(allowed) == 0 {
		return nil
	}
	principals := make([]string, 0, len(allowed))
	for _, raw := range allowed {
		value := strings.ReplaceAll(raw, "${username}", subject.Username)
		value = strings.ReplaceAll(value, "${sub}", subject.Sub)
		value = strings.TrimSpace(value)
		if value != "" {
			principals = append(principals, value)
		}
	}
	return principals
}

func parseDurationOrZero(raw string) time.Duration {
	if raw == "" {
		return 0
	}
	parsed, err := time.ParseDuration(raw)
	if err != nil {
		return 0
	}
	return parsed
}
