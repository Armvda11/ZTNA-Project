package middleware

import (
	"context"
	"encoding/json"
	"errors"
	"io"
	"net/http"
	"net/url"
	"strings"

	"control-plane/internal/config"
	domainErrors "control-plane/internal/domain/errors"
	"control-plane/internal/domain/model"

	"github.com/coreos/go-oidc/v3/oidc"
)

type ctxKey string

const subjectKey ctxKey = "subject"

type OIDCValidator struct {
	verifier *oidc.IDTokenVerifier
	cfg      config.OIDCConfig
	client   *http.Client
}

func NewOIDCValidator(ctx context.Context, cfg config.OIDCConfig) (*OIDCValidator, error) {
	provider, err := oidc.NewProvider(ctx, cfg.IssuerURL)
	if err != nil {
		return nil, err
	}

	verifier := provider.Verifier(&oidc.Config{
		ClientID:          cfg.Audience,
		SkipClientIDCheck: cfg.SkipAudienceCheck,
	})
	return &OIDCValidator{verifier: verifier, cfg: cfg, client: http.DefaultClient}, nil
}

func (v *OIDCValidator) RequireUser(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		token, err := bearerToken(r.Header.Get("Authorization"))
		if err != nil {
			writeError(w, domainErrors.ErrUnauthorized)
			return
		}

		subject, err := v.validateBearer(r.Context(), token)
		if err != nil {
			writeError(w, domainErrors.ErrUnauthorized)
			return
		}

		ctx := context.WithValue(r.Context(), subjectKey, subject)
		next.ServeHTTP(w, r.WithContext(ctx))
	})
}

func SubjectFromContext(ctx context.Context) (model.Subject, bool) {
	value := ctx.Value(subjectKey)
	subject, ok := value.(model.Subject)
	return subject, ok
}

func (v *OIDCValidator) validateBearer(ctx context.Context, token string) (model.Subject, error) {
	claims := map[string]any{}
	idToken, err := v.verifier.Verify(ctx, token)
	if err == nil {
		if err := idToken.Claims(&claims); err != nil {
			return model.Subject{}, err
		}
		if !v.cfg.SkipAudienceCheck && !audienceMatches(claims, v.cfg.Audience) {
			return model.Subject{}, errors.New("audience mismatch")
		}
		return subjectFromClaims(idToken.Subject, claims, v.cfg), nil
	}

	if v.cfg.IntrospectionURL == "" {
		return model.Subject{}, err
	}

	claims, active, err := v.introspect(ctx, token)
	if err != nil || !active {
		return model.Subject{}, errors.New("token inactive")
	}
	if !v.cfg.SkipAudienceCheck && !audienceMatches(claims, v.cfg.Audience) {
		return model.Subject{}, errors.New("audience mismatch")
	}

	return subjectFromClaims(claimString(claims, "sub"), claims, v.cfg), nil
}

func (v *OIDCValidator) introspect(ctx context.Context, token string) (map[string]any, bool, error) {
	form := url.Values{}
	form.Set("token", token)
	if v.cfg.IntrospectionClientID != "" && v.cfg.IntrospectionClientSecret != "" {
		form.Set("client_id", v.cfg.IntrospectionClientID)
		form.Set("client_secret", v.cfg.IntrospectionClientSecret)
	}

	req, err := http.NewRequestWithContext(ctx, http.MethodPost, v.cfg.IntrospectionURL, strings.NewReader(form.Encode()))
	if err != nil {
		return nil, false, err
	}
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	if v.cfg.IntrospectionClientID != "" && v.cfg.IntrospectionClientSecret != "" {
		req.SetBasicAuth(v.cfg.IntrospectionClientID, v.cfg.IntrospectionClientSecret)
	}

	resp, err := v.client.Do(req)
	if err != nil {
		return nil, false, err
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, false, err
	}
	if resp.StatusCode < 200 || resp.StatusCode > 299 {
		return nil, false, errors.New("introspection failed")
	}

	claims := map[string]any{}
	if err := json.Unmarshal(body, &claims); err != nil {
		return nil, false, err
	}

	active, _ := claims["active"].(bool)
	return claims, active, nil
}

func subjectFromClaims(subject string, claims map[string]any, cfg config.OIDCConfig) model.Subject {
	resolved := model.Subject{
		Sub:      subject,
		Username: claimString(claims, cfg.UsernameClaim),
		Groups:   claimStrings(claims, cfg.GroupsClaim),
	}
	if resolved.Username == "" {
		resolved.Username = resolved.Sub
	}
	return resolved
}

func audienceMatches(claims map[string]any, expected string) bool {
	if expected == "" {
		return true
	}
	raw, ok := claims["aud"]
	if !ok {
		return false
	}
	switch value := raw.(type) {
	case string:
		return value == expected
	case []any:
		for _, item := range value {
			if str, ok := item.(string); ok && str == expected {
				return true
			}
		}
	}
	return false
}

func bearerToken(header string) (string, error) {
	if header == "" {
		return "", errors.New("missing authorization")
	}
	parts := strings.SplitN(header, " ", 2)
	if len(parts) != 2 || !strings.EqualFold(parts[0], "Bearer") {
		return "", errors.New("invalid authorization")
	}
	return strings.TrimSpace(parts[1]), nil
}

func claimString(claims map[string]any, name string) string {
	if raw, ok := claims[name]; ok {
		if value, ok := raw.(string); ok {
			return value
		}
	}
	return ""
}

func claimStrings(claims map[string]any, name string) []string {
	raw, ok := claims[name]
	if !ok {
		return nil
	}
	switch value := raw.(type) {
	case []any:
		out := make([]string, 0, len(value))
		for _, item := range value {
			if str, ok := item.(string); ok {
				out = append(out, str)
			}
		}
		return out
	case []string:
		return value
	case string:
		trimmed := strings.TrimSpace(value)
		if trimmed == "" {
			return nil
		}
		if strings.Contains(trimmed, " ") {
			parts := strings.Fields(trimmed)
			return parts
		}
		if strings.Contains(trimmed, ",") {
			parts := strings.Split(trimmed, ",")
			out := make([]string, 0, len(parts))
			for _, part := range parts {
				p := strings.TrimSpace(part)
				if p != "" {
					out = append(out, p)
				}
			}
			return out
		}
		return []string{trimmed}
	default:
		return nil
	}
}
