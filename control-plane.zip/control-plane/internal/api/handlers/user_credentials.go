package handlers

import (
	"encoding/json"
	"net/http"
	"time"

	"control-plane/internal/api/middleware"
	domainErrors "control-plane/internal/domain/errors"
	"control-plane/internal/domain/model"
	"control-plane/internal/service/audit"
	"control-plane/internal/service/credentials"
)

type CredentialsHandler struct {
	creds *credentials.Service
	audit *audit.Service
}

func NewCredentialsHandler(creds *credentials.Service, auditSvc *audit.Service) *CredentialsHandler {
	return &CredentialsHandler{creds: creds, audit: auditSvc}
}

type sshCertRequest struct {
	PublicKey string `json:"public_key"`
	TTL       string `json:"ttl"`
}

type sshCertResponse struct {
	Certificate string    `json:"certificate"`
	ValidBefore time.Time `json:"valid_before"`
	Principal   string    `json:"principal"`
}

func (h *CredentialsHandler) IssueSSHCert(w http.ResponseWriter, r *http.Request) {
	subject, ok := middleware.SubjectFromContext(r.Context())
	if !ok {
		writeError(w, domainErrors.ErrUnauthorized)
		return
	}

	var req sshCertRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeError(w, domainErrors.ErrInvalidInput)
		return
	}
	if req.PublicKey == "" {
		writeError(w, domainErrors.ErrInvalidInput)
		return
	}

	var ttl *time.Duration
	if req.TTL != "" {
		parsed, err := time.ParseDuration(req.TTL)
		if err != nil {
			writeError(w, domainErrors.ErrInvalidInput)
			return
		}
		ttl = &parsed
	}

	resp, err := h.creds.IssueSSHCert(r.Context(), credentials.IssueRequest{
		Subject:   subject,
		PublicKey: req.PublicKey,
		TTL:       ttl,
	})
	if err != nil {
		writeError(w, err)
		return
	}

	sourceIP := extractRemoteIP(r)
	_ = h.audit.Append(r.Context(), model.AuditEvent{
		Subject:       subject.Username,
		Action:        "issue_ssh_cert",
		Resource:      "ssh_cert",
		Decision:      "allow",
		Reason:        "issued",
		PepID:         "",
		SourceIP:      sourceIP,
		PolicyVersion: 0,
	})

	writeJSON(w, http.StatusOK, sshCertResponse{
		Certificate: resp.Certificate,
		ValidBefore: resp.ValidBefore,
		Principal:   resp.Principal,
	})
}
