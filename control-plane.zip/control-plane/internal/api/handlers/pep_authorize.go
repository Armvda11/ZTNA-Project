package handlers

import (
	"encoding/json"
	"net/http"

	domainErrors "control-plane/internal/domain/errors"
	"control-plane/internal/domain/model"
	"control-plane/internal/logger"
	"control-plane/internal/service/audit"
	"control-plane/internal/service/decision"
)

type PEPHandler struct {
	decision *decision.Service
	audit    *audit.Service
}

func NewPEPHandler(decisionSvc *decision.Service, auditSvc *audit.Service) *PEPHandler {
	return &PEPHandler{decision: decisionSvc, audit: auditSvc}
}

type authorizeRequest struct {
	Subject  model.Subject  `json:"subject"`
	Action   string         `json:"action"`
	Resource model.Resource `json:"resource"`
	Context  map[string]any `json:"context"`
}

func (h *PEPHandler) Authorize(w http.ResponseWriter, r *http.Request) {
	var req authorizeRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeError(w, domainErrors.ErrInvalidInput)
		return
	}
	if req.Action == "" || req.Resource.Type == "" {
		writeError(w, domainErrors.ErrInvalidInput)
		return
	}

	decisionResp, err := h.decision.Authorize(r.Context(), decision.AuthorizeRequest{
		Subject:  req.Subject,
		Action:   req.Action,
		Resource: req.Resource,
		Context:  req.Context,
	})
	if err != nil {
		writeError(w, err)
		return
	}

	pepID := logger.PepIDFromContext(r.Context())
	sourceIP := extractContextIP(req.Context)
	if sourceIP == "" {
		sourceIP = extractRemoteIP(r)
	}
	_ = h.audit.Append(r.Context(), model.AuditEvent{
		Subject:       req.Subject.Username,
		Action:        req.Action,
		Resource:      req.Resource.Canonical(),
		Decision:      string(decisionResp.Effect),
		Reason:        decisionResp.Reason,
		PepID:         pepID,
		SourceIP:      sourceIP,
		PolicyVersion: decisionResp.PolicyVersion,
	})

	writeJSON(w, http.StatusOK, decisionResp)
}
