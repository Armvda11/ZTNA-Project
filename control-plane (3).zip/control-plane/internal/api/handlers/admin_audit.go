package handlers

import (
	"net/http"
	"strconv"

	"control-plane/internal/service/audit"
)

type AdminAuditHandler struct {
	audit *audit.Service
}

func NewAdminAuditHandler(auditSvc *audit.Service) *AdminAuditHandler {
	return &AdminAuditHandler{audit: auditSvc}
}

func (h *AdminAuditHandler) List(w http.ResponseWriter, r *http.Request) {
	limit := 100
	if raw := r.URL.Query().Get("limit"); raw != "" {
		if parsed, err := strconv.Atoi(raw); err == nil {
			limit = parsed
		}
	}

	events, err := h.audit.List(r.Context(), limit)
	if err != nil {
		writeError(w, err)
		return
	}

	writeJSON(w, http.StatusOK, events)
}
