package handlers

import (
    "net/http"

    "control-plane/internal/api/middleware"
    domainErrors "control-plane/internal/domain/errors"
)

type WhoamiHandler struct{}

func NewWhoamiHandler() *WhoamiHandler {
    return &WhoamiHandler{}
}

func (h *WhoamiHandler) Get(w http.ResponseWriter, r *http.Request) {
    subject, ok := middleware.SubjectFromContext(r.Context())
    if !ok {
        writeError(w, domainErrors.ErrUnauthorized)
        return
    }

    writeJSON(w, http.StatusOK, subject)
}
