package middleware

import (
	"net/http"

	"control-plane/internal/config"
	domainErrors "control-plane/internal/domain/errors"
)

type AdminAuth struct {
	cfg config.OIDCConfig
}

func NewAdminAuth(cfg config.OIDCConfig) *AdminAuth {
	return &AdminAuth{cfg: cfg}
}

func (a *AdminAuth) RequireAdmin(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		subject, ok := SubjectFromContext(r.Context())
		if !ok {
			writeError(w, domainErrors.ErrUnauthorized)
			return
		}
		if a.cfg.AdminGroup == "" {
			writeError(w, domainErrors.ErrForbidden)
			return
		}
		for _, group := range subject.Groups {
			if group == a.cfg.AdminGroup {
				next.ServeHTTP(w, r)
				return
			}
		}
		writeError(w, domainErrors.ErrForbidden)
	})
}
